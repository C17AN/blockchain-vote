'use strict';

module.exports = require('./inject')(require('acorn'));
